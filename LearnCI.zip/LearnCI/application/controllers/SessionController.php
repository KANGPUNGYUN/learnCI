<?php defined('BASEPATH') OR exit('No direct script access allowed');
	class SessionController extends CI_Controller {
	    public function __construct() {
	        Parent:: __construct();
	        $this->load->helper('url');
	        $this->load->library('session');
	    }
	
	    public function index() {
            $this->load->view('sessions/index');
	    }
	 
	    public function flash_message(){
	        $this->session->set_flashdata('msg', '코드이그나이터 플래시 메시지를 정상적으로 작동합니다.');
	        redirect(base_url('flash_index'));
	    }

        public function check_auth($page) {
            if (!$this->session->userdata('logged_in')) {
                $this->session->set_flashdata('msg', "$page 페이지를 사용하시려면 먼저 로그인하셔야 됩니다");
                redirect('login');
            }
        }
        	 
        public function login() {
            $this->load->view('sessions/login');
        }
            	 
        public function authenticate() {
            $this->session->set_userdata('username', '홍길동');
            $this->session->set_userdata('logged_in', TRUE); 
            redirect(base_url('dashboard'));
        }
            	 
        public function dashboard() {
            $this->check_auth('dashboard');
            $this->load->view('sessions/dashboard');
        }
            	 
        public function settings() {
            $this->check_auth('settings');
            $this->load->view('sessions/settings');
        }
            	 
        public function logout() {
            $this->session->unset_userdata('username');
            $this->session->unset_userdata('logged_in'); 
            redirect(base_url('login'));
        }
            
	} 
?>