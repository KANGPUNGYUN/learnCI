<html>
    <head>
        <title>코드이그나이터 세션으로 플래시 메시지 전달하기</title>
    </head>
    <body>
        <p>플래시 메시지:<b> <?php echo $this->session->userdata('msg');?> </b></p>
    </body>
</html>