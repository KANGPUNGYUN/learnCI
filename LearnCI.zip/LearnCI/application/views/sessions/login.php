<!DOCTYPE html>
<html>
    <head>
        <title>로그인</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.min.css">
    </head>
    <body>
        <div class="container">
            <div class="column">
                <p><?php echo $this->session->userdata('msg');?></p>
                <form method="post" action="<?php echo site_url('authenticate');?>">
                    <div class="field">
                        <label class="label">ID</label>
                        <div class="control">
                            <input class="input" type="text" placeholder="Text input">
                        </div>
                    </div>
                    <div class="field">
                        <label class="label">비밀번호</label>
                        <div class="control">
                            <input class="input" type="passport" placeholder="Text input">
                        </div>
                    </div>
                    <div class="field is-grouped">
                        <div class="control">
                            <button class="button is-success">로그인</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </body>
</html>
