<!DOCTYPE html>
<html>
    <head>
        <title>설정</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
	        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.2/css/bulma.min.css">
    </head>
    <body>
        <div class="container">
            <div class="column">
                <nav class="navbar" role="navigation" aria-label="main navigation">
                    <div id="navbarBasicExample" class="navbar-menu">
                        <div class="navbar-start">
                            <a href="<?php echo site_url('dashboard');?>" class="navbar-item">대시보드</a>
                            <a href="<?php echo site_url('settings');?>" class="navbar-item">설정</a>
                        </div>
    
                        <div class="navbar-end">
                            <div class="navbar-item has-dropdown is-hoverable">
                                <a class="navbar-link">홍길동</a>
    
                                <div class="navbar-dropdown">
                                    <a href="#" class="navbar-item">마이페이지</a>
                                    <hr class="navbar-divider">
                                    <a href="<?php echo site_url('logout');?>" class="navbar-item">로그아웃</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </nav>
                <h3>설정페이지</h3>
            </div>
        </div>
    </body>
</html>
